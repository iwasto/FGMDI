"""Confidence-switched graph-diffusion operators."""

import numpy as np

from config import HEAT_ORDER, HEAT_T


def exact_ppr_diffusion(X_log, T, restart_prob=0.15):
    """Exact PPR diffusion retained for compatibility and experimentation."""
    n_cells = T.shape[0]
    M = np.eye(n_cells) - (1.0 - restart_prob) * T
    return restart_prob * np.linalg.solve(M, X_log.T).T


def polynomial_diffusion(X_log, T, coeffs):
    """Finite polynomial diffusion over the cell-transition matrix."""
    coeffs = np.asarray(coeffs, dtype=float)
    coeffs = coeffs / (np.sum(coeffs) + 1e-12)

    output = coeffs[0] * X_log
    Xk = X_log

    for coefficient in coeffs[1:]:
        Xk = Xk @ T.T
        output = output + coefficient * Xk

    return output


def heat_kernel_diffusion(X_log, T, t=HEAT_T, order=HEAT_ORDER):
    """Truncated heat-kernel diffusion."""
    coeffs = []
    factorial = 1.0

    for k in range(order + 1):
        if k > 0:
            factorial *= k
        coeffs.append(np.exp(-t) * (t ** k) / factorial)

    return polynomial_diffusion(X_log, T, coeffs)
