"""Input loading, normalization, and artificial-dropout utilities."""

from pathlib import Path

import numpy as np
import pandas as pd

from config import RANDOM_STATE


def validate_count_matrix(count_df: pd.DataFrame) -> pd.DataFrame:
    """Validate a genes-by-cells non-negative count matrix."""
    if count_df.empty:
        raise ValueError("The input count matrix is empty.")

    numeric_df = count_df.apply(pd.to_numeric, errors="coerce")
    if numeric_df.isna().any().any():
        raise ValueError("The input matrix contains non-numeric or missing values.")

    values = numeric_df.to_numpy(dtype=float)
    if not np.isfinite(values).all():
        raise ValueError("The input matrix contains NaN or infinite values.")
    if (values < 0).any():
        raise ValueError("The input matrix contains negative values.")
    if numeric_df.shape[0] < 2:
        raise ValueError("At least two genes are required.")
    if numeric_df.shape[1] < 3:
        raise ValueError("At least three cells are required.")

    return numeric_df


def load_count_matrix(path) -> pd.DataFrame:
    """Load a CSV matrix whose rows are genes and columns are cells."""
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(f"Input file does not exist: {path}")

    count_df = pd.read_csv(path, index_col=0)
    return validate_count_matrix(count_df)


def load_pair(true_path, masked_path):
    """Load and align a ground-truth matrix and its masked counterpart."""
    true_df = load_count_matrix(true_path)
    masked_df = pd.read_csv(masked_path, index_col=0)
    masked_df = masked_df.reindex(index=true_df.index, columns=true_df.columns)
    masked_df = validate_count_matrix(masked_df)
    return true_df, masked_df


def depth_normalized_log(count_df):
    """Median-depth rescaling followed by log2(x + 1)."""
    X_raw = count_df.values.astype(float)
    depths = np.sum(X_raw, axis=0) + 1e-6
    med_depth = np.median(depths)
    X_norm = (X_raw / depths) * med_depth
    X_log = np.log2(X_norm + 1.0)
    return X_log, depths, med_depth


def create_dropout_from_true(
    true_path,
    output_path,
    dropout_rate,
    random_state=RANDOM_STATE,
):
    """Randomly set a proportion of true nonzero entries to zero."""
    if not 0.0 <= dropout_rate <= 1.0:
        raise ValueError("dropout_rate must lie between 0 and 1.")

    true_df = load_count_matrix(true_path)
    masked_values = true_df.values.copy()

    flat = masked_values.reshape(-1)
    nonzero_idx = np.flatnonzero(flat > 0)
    n_drop = int(np.floor(len(nonzero_idx) * dropout_rate))

    rng = np.random.default_rng(random_state)
    if n_drop > 0:
        drop_idx = rng.choice(nonzero_idx, size=n_drop, replace=False)
        flat[drop_idx] = 0

    masked_df = pd.DataFrame(
        masked_values,
        index=true_df.index,
        columns=true_df.columns,
    )

    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    masked_df.to_csv(output_path)

    return {
        "path": str(output_path),
        "dropout_rate": float(dropout_rate),
        "dropped_nonzero": int(n_drop),
        "zero_rate": float(np.mean(masked_values == 0)),
    }
