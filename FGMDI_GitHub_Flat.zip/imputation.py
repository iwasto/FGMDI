"""FGMDI model implementation."""

import numpy as np
import pandas as pd

from config import (
    DEFAULT_CONFIDENCE_THRESHOLD,
    GPR_MID_COEFFS,
    HEAT_ORDER,
    HEAT_T,
)
from diffusion import heat_kernel_diffusion, polynomial_diffusion
from graph_construction import (
    build_cosine_knn_micro_graph,
    build_scanpy_macro_graph,
    compute_zero_support_confidence,
    fuse_graphs,
    transition_from_adjacency,
)
from preprocessing import depth_normalized_log, validate_count_matrix


class FGMDI:
    """
    Fast Graph-fusion and Multi-gate Diffusion Imputation.

    Input:
        pandas.DataFrame with rows = genes and columns = cells.

    Output:
        imputed pandas.DataFrame with the same index and columns.
    """

    def __init__(
        self,
        method_name="FGMDI",
        confidence_threshold=DEFAULT_CONFIDENCE_THRESHOLD,
        fusion_alpha=0.6,
        restart_prob=0.15,
        k_micro=5,
        k_macro=30,
        diffusion_macro_method="gauss",
        gate_macro_method="umap",
        gpr_coeffs=None,
        heat_t=HEAT_T,
        heat_order=HEAT_ORDER,
        base_threshold=0.15,
        max_threshold=0.92,
        support_power=2.0,
        source_zero_cutoff=0.58,
        low_zero_reference=0.40,
        strict_boost_power=2.0,
        low_zero_base_extra=0.06,
        low_zero_extra_max=0.05,
        low_zero_power_drop=0.95,
        gene_penalty_max=0.12,
        gene_prior_power=2.0,
        gene_local_interaction_power=1.0,
        low_support_extra=0.03,
        low_support_cutoff=0.55,
        low_support_power=2.0,
    ):
        self.method_name = method_name
        self.confidence_threshold = confidence_threshold
        self.alpha = fusion_alpha
        self.restart_prob = restart_prob
        self.k_micro = k_micro
        self.k_macro = k_macro
        self.diffusion_macro_method = diffusion_macro_method
        self.gate_macro_method = gate_macro_method
        self.gpr_coeffs = list(gpr_coeffs or GPR_MID_COEFFS)
        self.heat_t = heat_t
        self.heat_order = heat_order

        self.base_threshold = base_threshold
        self.max_threshold = max_threshold
        self.support_power = support_power
        self.source_zero_cutoff = source_zero_cutoff
        self.low_zero_reference = low_zero_reference
        self.strict_boost_power = strict_boost_power
        self.low_zero_base_extra = low_zero_base_extra
        self.low_zero_extra_max = low_zero_extra_max
        self.low_zero_power_drop = low_zero_power_drop

        self.gene_penalty_max = gene_penalty_max
        self.gene_prior_power = gene_prior_power
        self.gene_local_interaction_power = gene_local_interaction_power

        self.low_support_extra = low_support_extra
        self.low_support_cutoff = low_support_cutoff
        self.low_support_power = low_support_power

    def _build_graphs(self, X_log):
        A_micro = build_cosine_knn_micro_graph(
            X_log,
            k_micro=self.k_micro,
        )

        A_macro_umap = build_scanpy_macro_graph(
            X_log,
            k_macro=self.k_macro,
            method="umap",
        )

        if self.diffusion_macro_method == "umap":
            A_macro_diffusion = A_macro_umap
        elif self.diffusion_macro_method == "gauss":
            A_macro_diffusion = build_scanpy_macro_graph(
                X_log,
                k_macro=self.k_macro,
                method="gauss",
            )
        else:
            raise ValueError(
                "diffusion_macro_method must be 'umap' or 'gauss'."
            )

        if self.gate_macro_method == "umap":
            A_macro_gate = A_macro_umap
        elif self.gate_macro_method == "gauss":
            if self.diffusion_macro_method == "gauss":
                A_macro_gate = A_macro_diffusion
            else:
                A_macro_gate = build_scanpy_macro_graph(
                    X_log,
                    k_macro=self.k_macro,
                    method="gauss",
                )
        else:
            raise ValueError("gate_macro_method must be 'umap' or 'gauss'.")

        return A_micro, A_macro_diffusion, A_macro_gate

    def _select_and_diffuse(self, X_log, T, confidence):
        if confidence < self.confidence_threshold:
            selected_diffusion = "gpr_mid"
            X_diff_log = polynomial_diffusion(
                X_log,
                T,
                self.gpr_coeffs,
            )
        else:
            selected_diffusion = "heat_kernel"
            X_diff_log = heat_kernel_diffusion(
                X_log,
                T,
                t=self.heat_t,
                order=self.heat_order,
            )

        return X_diff_log, selected_diffusion

    def fit_transform(self, count_df, return_diagnostics=False):
        count_df = validate_count_matrix(count_df)

        X_raw = count_df.values.astype(float)
        X_log, depths, med_depth = depth_normalized_log(count_df)

        A_micro, A_macro_diffusion, A_macro_gate = self._build_graphs(X_log)
        A_fused = fuse_graphs(
            A_micro,
            A_macro_diffusion,
            fusion_alpha=self.alpha,
        )
        T = transition_from_adjacency(A_fused)

        zero_mask = X_raw == 0
        zero_rate = float(np.mean(zero_mask))

        confidence, neighbor_freq = compute_zero_support_confidence(
            X_raw,
            A_macro_gate,
        )

        X_diff_log, selected_diffusion = self._select_and_diffuse(
            X_log,
            T,
            confidence,
        )

        X_diff_norm = (2.0 ** X_diff_log) - 1.0
        X_diff_raw = (X_diff_norm / med_depth) * depths
        X_diff_raw = np.maximum(X_diff_raw, 0.0)

        if zero_rate >= self.source_zero_cutoff:
            mode = "high-sparsity source mode"
            final_threshold = np.full_like(
                neighbor_freq,
                self.base_threshold,
                dtype=float,
            )
            low_support_penalty = np.zeros_like(
                neighbor_freq,
                dtype=float,
            )
            imputation_mask = zero_mask & (
                neighbor_freq > self.base_threshold
            )
        else:
            mode = "low/mid-sparsity adaptive mode"

            low_zero_strength = (
                (self.source_zero_cutoff - zero_rate)
                / (
                    self.source_zero_cutoff
                    - self.low_zero_reference
                    + 1e-8
                )
            )
            low_zero_strength = np.clip(
                low_zero_strength,
                0.0,
                1.0,
            )
            strict_boost = (
                low_zero_strength ** self.strict_boost_power
            )

            dynamic_base_threshold = np.clip(
                self.base_threshold
                + self.low_zero_base_extra * strict_boost,
                self.base_threshold,
                0.35,
            )
            dynamic_max_threshold = np.clip(
                self.max_threshold
                + self.low_zero_extra_max * strict_boost,
                dynamic_base_threshold,
                0.98,
            )
            dynamic_support_power = np.clip(
                self.support_power
                - self.low_zero_power_drop * strict_boost,
                1.15,
                self.support_power,
            )

            zero_count_per_gene = np.sum(
                zero_mask,
                axis=1,
                keepdims=True,
            )
            gene_dropout_prior = (
                np.sum(
                    neighbor_freq * zero_mask,
                    axis=1,
                    keepdims=True,
                )
                / (zero_count_per_gene + 1e-8)
            )
            gene_dropout_prior = np.nan_to_num(
                gene_dropout_prior,
                nan=0.0,
                posinf=1.0,
                neginf=0.0,
            )
            gene_dropout_prior = np.clip(
                gene_dropout_prior,
                0.0,
                1.0,
            )

            local_support_threshold = (
                dynamic_base_threshold
                + (
                    dynamic_max_threshold
                    - dynamic_base_threshold
                )
                * (
                    (1.0 - neighbor_freq)
                    ** dynamic_support_power
                )
            )
            local_support_threshold = np.nan_to_num(
                local_support_threshold,
                nan=dynamic_max_threshold,
                posinf=dynamic_max_threshold,
                neginf=dynamic_base_threshold,
            )
            local_support_threshold = np.clip(
                local_support_threshold,
                dynamic_base_threshold,
                dynamic_max_threshold,
            )

            gene_penalty = (
                self.gene_penalty_max
                * (
                    (1.0 - gene_dropout_prior)
                    ** self.gene_prior_power
                )
                * (
                    (1.0 - neighbor_freq)
                    ** self.gene_local_interaction_power
                )
            )
            gene_penalty = gene_penalty * strict_boost
            gene_penalty = np.nan_to_num(
                gene_penalty,
                nan=0.0,
                posinf=self.gene_penalty_max,
                neginf=0.0,
            )

            support_deficit = np.clip(
                (
                    self.low_support_cutoff
                    - neighbor_freq
                )
                / (self.low_support_cutoff + 1e-8),
                0.0,
                1.0,
            )
            low_support_penalty = (
                self.low_support_extra
                * strict_boost
                * (
                    support_deficit
                    ** self.low_support_power
                )
            )

            final_threshold = (
                local_support_threshold
                + gene_penalty
                + low_support_penalty
            )
            final_threshold = np.nan_to_num(
                final_threshold,
                nan=dynamic_max_threshold,
                posinf=dynamic_max_threshold,
                neginf=dynamic_base_threshold,
            )
            final_threshold = np.clip(
                final_threshold,
                dynamic_base_threshold,
                dynamic_max_threshold,
            )

            imputation_mask = zero_mask & (
                neighbor_freq > final_threshold
            )

        X_imputed = np.where(
            imputation_mask,
            X_diff_raw,
            X_raw,
        )
        imputed_df = pd.DataFrame(
            X_imputed,
            index=count_df.index,
            columns=count_df.columns,
        )

        zero_neighbor_values = neighbor_freq[zero_mask]
        zero_threshold_values = final_threshold[zero_mask]
        zero_low_penalty_values = low_support_penalty[zero_mask]

        if zero_neighbor_values.size > 0:
            neighbor_q = np.quantile(
                zero_neighbor_values,
                [0.10, 0.50, 0.90],
            )
            threshold_q = np.quantile(
                zero_threshold_values,
                [0.10, 0.50, 0.90],
            )
            low_penalty_q = np.quantile(
                zero_low_penalty_values,
                [0.10, 0.50, 0.90],
            )
        else:
            neighbor_q = [np.nan, np.nan, np.nan]
            threshold_q = [np.nan, np.nan, np.nan]
            low_penalty_q = [np.nan, np.nan, np.nan]

        diagnostics = {
            "method": self.method_name,
            "mode": mode,
            "selected_diffusion": selected_diffusion,
            "confidence_metric": "zero_support_q50",
            "confidence_score": float(confidence),
            "confidence_threshold": float(
                self.confidence_threshold
            ),
            "zero_rate": zero_rate,
            "total_zero": int(np.sum(zero_mask)),
            "imputed_zeros": int(np.sum(imputation_mask)),
            "impute_ratio": float(
                np.sum(imputation_mask)
                / (X_raw.size + 1e-8)
            ),
            "micro_graph": "cosine_knn",
            "diffusion_macro_graph": (
                self.diffusion_macro_method
            ),
            "gate_macro_graph": self.gate_macro_method,
            "fusion_alpha": float(self.alpha),
            "k_micro": int(self.k_micro),
            "k_macro": int(self.k_macro),
            "gpr_coeffs": ",".join(
                str(value)
                for value in self.gpr_coeffs
            ),
            "heat_t": float(self.heat_t),
            "heat_order": int(self.heat_order),
            "micro_nnz": int(A_micro.nnz),
            "diffusion_macro_nnz": int(
                A_macro_diffusion.nnz
            ),
            "gate_macro_nnz": int(A_macro_gate.nnz),
            "neighbor_q10": float(neighbor_q[0]),
            "neighbor_q50": float(neighbor_q[1]),
            "neighbor_q90": float(neighbor_q[2]),
            "threshold_q10": float(threshold_q[0]),
            "threshold_q50": float(threshold_q[1]),
            "threshold_q90": float(threshold_q[2]),
            "low_penalty_q10": float(
                low_penalty_q[0]
            ),
            "low_penalty_q50": float(
                low_penalty_q[1]
            ),
            "low_penalty_q90": float(
                low_penalty_q[2]
            ),
        }

        if return_diagnostics:
            return imputed_df, diagnostics

        return imputed_df


# Compatibility with the original class name.
FinalConfidenceSwitchTGPPR = FGMDI


def make_fgmdi():
    """Return an FGMDI model with the default configuration."""
    return FGMDI()
