"""Evaluation metrics for FGMDI experiments."""

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import scanpy as sc
from sklearn.cluster import KMeans
from sklearn.metrics import (
    adjusted_rand_score,
    f1_score,
    normalized_mutual_info_score,
)
from sklearn.metrics.cluster import contingency_matrix

from config import RANDOM_STATE
from preprocessing import load_pair


sc.settings.verbosity = 0
sc.settings.seed = RANDOM_STATE


def l1_distance(imputed_data, original_data):
    return float(np.mean(np.abs(original_data - imputed_data)))


def rmse(imputed_data, original_data):
    return float(
        np.sqrt(
            np.mean(
                (original_data - imputed_data) ** 2
            )
        )
    )


def pearson_corr(imputed_data, original_data):
    y = np.asarray(original_data).reshape(-1)
    pred = np.asarray(imputed_data).reshape(-1)

    y_mean = np.mean(y)
    pred_mean = np.mean(pred)

    numerator = np.sum(
        (pred - pred_mean) * (y - y_mean)
    )
    denominator = (
        np.sqrt(
            np.sum((pred - pred_mean) ** 2)
        )
        * np.sqrt(
            np.sum((y - y_mean) ** 2)
        )
        + 1e-12
    )

    return float(numerator / denominator)


def purity_score(y_true, y_pred):
    contingency = contingency_matrix(y_true, y_pred)
    return float(
        np.sum(np.amax(contingency, axis=0))
        / np.sum(contingency)
    )


def get_clusters(
    data_matrix,
    n_clusters=7,
    random_state=RANDOM_STATE,
):
    """Cluster cells after standard Scanpy preprocessing."""
    adata = sc.AnnData(data_matrix.T)
    sc.pp.normalize_total(adata, target_sum=1e4)
    sc.pp.log1p(adata)

    n_comps = min(
        50,
        data_matrix.shape[0] - 1,
        data_matrix.shape[1] - 1,
    )
    n_comps = max(1, n_comps)
    sc.pp.pca(adata, n_comps=n_comps)

    return KMeans(
        n_clusters=n_clusters,
        random_state=random_state,
        n_init=10,
    ).fit_predict(adata.obsm["X_pca"])


def evaluate_imputation(
    true_df,
    masked_df,
    imputed_df,
    n_clusters=7,
):
    """Evaluate recovery and clustering quality."""
    true_expr = true_df.values.astype(float)
    masked_expr = masked_df.values.astype(float)
    imputed_expr = imputed_df.values.astype(float)

    true_log = np.log2(true_expr + 1.0)
    masked_log = np.log2(masked_expr + 1.0)
    imputed_log = np.log2(imputed_expr + 1.0)

    true_labels = get_clusters(
        true_expr,
        n_clusters=n_clusters,
    )
    masked_labels = get_clusters(
        masked_expr,
        n_clusters=n_clusters,
    )
    imputed_labels = get_clusters(
        imputed_expr,
        n_clusters=n_clusters,
    )

    zero_mask = masked_expr == 0
    if np.any(zero_mask):
        f1 = f1_score(
            (true_expr[zero_mask] > 0).astype(int),
            (imputed_expr[zero_mask] > 0.01).astype(int),
        )
    else:
        f1 = np.nan

    return {
        "baseline_pcc": pearson_corr(
            masked_log,
            true_log,
        ),
        "baseline_l1": l1_distance(
            masked_log,
            true_log,
        ),
        "baseline_rmse": rmse(
            masked_log,
            true_log,
        ),
        "baseline_ari": float(
            adjusted_rand_score(
                true_labels,
                masked_labels,
            )
        ),
        "baseline_nmi": float(
            normalized_mutual_info_score(
                true_labels,
                masked_labels,
            )
        ),
        "baseline_purity": purity_score(
            true_labels,
            masked_labels,
        ),
        "pcc": pearson_corr(
            imputed_log,
            true_log,
        ),
        "l1": l1_distance(
            imputed_log,
            true_log,
        ),
        "rmse": rmse(
            imputed_log,
            true_log,
        ),
        "ari": float(
            adjusted_rand_score(
                true_labels,
                imputed_labels,
            )
        ),
        "nmi": float(
            normalized_mutual_info_score(
                true_labels,
                imputed_labels,
            )
        ),
        "purity": purity_score(
            true_labels,
            imputed_labels,
        ),
        "f1": float(f1),
    }


def main():
    parser = argparse.ArgumentParser(
        description="Evaluate an FGMDI result."
    )
    parser.add_argument("--true", required=True)
    parser.add_argument("--masked", required=True)
    parser.add_argument("--imputed", required=True)
    parser.add_argument(
        "--clusters",
        type=int,
        required=True,
    )
    parser.add_argument(
        "--output",
        default=None,
        help="Optional JSON result file.",
    )
    args = parser.parse_args()

    true_df, masked_df = load_pair(
        args.true,
        args.masked,
    )
    imputed_df = pd.read_csv(
        args.imputed,
        index_col=0,
    ).reindex(
        index=true_df.index,
        columns=true_df.columns,
    )

    metrics = evaluate_imputation(
        true_df,
        masked_df,
        imputed_df,
        n_clusters=args.clusters,
    )

    output_text = json.dumps(
        metrics,
        indent=2,
        ensure_ascii=False,
    )
    print(output_text)

    if args.output:
        Path(args.output).write_text(
            output_text,
            encoding="utf-8",
        )


if __name__ == "__main__":
    main()
