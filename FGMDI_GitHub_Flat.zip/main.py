"""Command-line entry point for FGMDI."""

import argparse
import json
from pathlib import Path

from imputation import FGMDI
from preprocessing import load_count_matrix


def build_parser():
    parser = argparse.ArgumentParser(
        description=(
            "Run FGMDI on a genes-by-cells "
            "scRNA-seq count matrix."
        )
    )
    parser.add_argument(
        "--input",
        required=True,
        help="Input CSV count matrix.",
    )
    parser.add_argument(
        "--output",
        default="FGMDI_imputed.csv",
        help="Output imputed CSV.",
    )
    parser.add_argument(
        "--diagnostics",
        default="FGMDI_diagnostics.json",
        help="Output diagnostic JSON.",
    )
    parser.add_argument(
        "--k-micro",
        type=int,
        default=5,
    )
    parser.add_argument(
        "--k-macro",
        type=int,
        default=30,
    )
    parser.add_argument(
        "--fusion-alpha",
        type=float,
        default=0.6,
    )
    parser.add_argument(
        "--confidence-threshold",
        type=float,
        default=0.281878,
    )
    return parser


def main():
    args = build_parser().parse_args()
    count_df = load_count_matrix(args.input)

    n_cells = count_df.shape[1]
    k_micro = min(
        max(1, args.k_micro),
        n_cells - 1,
    )
    k_macro = min(
        max(2, args.k_macro),
        n_cells - 1,
    )

    model = FGMDI(
        confidence_threshold=args.confidence_threshold,
        fusion_alpha=args.fusion_alpha,
        k_micro=k_micro,
        k_macro=k_macro,
    )

    imputed_df, diagnostics = model.fit_transform(
        count_df,
        return_diagnostics=True,
    )

    output_path = Path(args.output)
    diagnostics_path = Path(args.diagnostics)

    output_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )
    diagnostics_path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    imputed_df.to_csv(output_path)
    diagnostics_path.write_text(
        json.dumps(
            diagnostics,
            indent=2,
            ensure_ascii=False,
        ),
        encoding="utf-8",
    )

    print(
        f"Input shape: "
        f"{count_df.shape[0]} genes x "
        f"{count_df.shape[1]} cells"
    )
    print(
        "Selected diffusion:",
        diagnostics["selected_diffusion"],
    )
    print(
        "Confidence score:",
        f"{diagnostics['confidence_score']:.6f}",
    )
    print(
        "Imputed zeros:",
        diagnostics["imputed_zeros"],
    )
    print("Imputed matrix:", output_path)
    print("Diagnostics:", diagnostics_path)


if __name__ == "__main__":
    main()
