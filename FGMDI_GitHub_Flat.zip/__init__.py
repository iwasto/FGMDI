"""FGMDI source-code interface."""

try:
    from .imputation import (
        FGMDI,
        FinalConfidenceSwitchTGPPR,
        make_fgmdi,
    )
except ImportError:
    from imputation import (
        FGMDI,
        FinalConfidenceSwitchTGPPR,
        make_fgmdi,
    )

__all__ = [
    "FGMDI",
    "FinalConfidenceSwitchTGPPR",
    "make_fgmdi",
]
