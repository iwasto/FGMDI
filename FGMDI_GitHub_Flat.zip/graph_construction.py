"""Dual-scale graph construction and neighborhood-support estimation."""

import numpy as np
import scanpy as sc
from scipy import sparse
from sklearn.neighbors import kneighbors_graph

from config import RANDOM_STATE


sc.settings.verbosity = 0
sc.settings.seed = RANDOM_STATE


def build_cosine_knn_micro_graph(X_log, k_micro=5):
    """Construct a symmetric cosine-similarity micro-neighborhood graph."""
    n_cells = X_log.shape[1]
    k_micro = min(max(1, int(k_micro)), n_cells - 1)

    A = kneighbors_graph(
        X_log.T,
        n_neighbors=k_micro,
        mode="distance",
        metric="cosine",
        n_jobs=-1,
    )
    A.data = np.clip(1.0 - A.data, 0.0, 1.0)
    A = A.maximum(A.T)
    A.setdiag(0.0)
    A.eliminate_zeros()
    return A.tocsr()


def build_scanpy_macro_graph(X_log, k_macro=30, method="umap"):
    """Construct a Scanpy UMAP- or Gaussian-connectivity macro graph."""
    n_cells = X_log.shape[1]
    k_macro = min(max(2, int(k_macro)), n_cells - 1)

    adata = sc.AnnData(X_log.T)
    n_comps = min(50, X_log.shape[0] - 1, X_log.shape[1] - 1)
    n_comps = max(1, n_comps)

    sc.pp.pca(adata, n_comps=n_comps)
    sc.pp.neighbors(
        adata,
        n_neighbors=k_macro,
        use_rep="X_pca",
        method=method,
        metric="cosine",
        random_state=RANDOM_STATE,
    )

    A = adata.obsp["connectivities"].tocsr()
    A.setdiag(0.0)
    A.eliminate_zeros()
    return A


def fuse_graphs(A_micro, A_macro, fusion_alpha=0.6):
    """Fuse micro and macro graphs."""
    if not 0.0 <= fusion_alpha <= 1.0:
        raise ValueError("fusion_alpha must lie between 0 and 1.")

    A_fused = fusion_alpha * A_macro + (1.0 - fusion_alpha) * A_micro
    A_fused = A_fused.tocsr()
    A_fused.setdiag(0.0)
    A_fused.eliminate_zeros()
    return A_fused


def transition_from_adjacency(A_fused):
    """Build a row-normalized transition matrix."""
    degrees = np.asarray(A_fused.sum(axis=1)).ravel()
    D_inv = sparse.diags(1.0 / (degrees + 1e-10))
    return D_inv.dot(A_fused).toarray()


def compute_neighbor_frequency(X_raw, A_gate):
    """Estimate gene-specific expression support from neighboring cells."""
    X_bool = (X_raw > 0).astype(float)
    neighbor_votes = (A_gate.dot(X_bool.T)).T

    if sparse.issparse(neighbor_votes):
        neighbor_votes = neighbor_votes.toarray()

    cell_degree = np.asarray(A_gate.sum(axis=1)).ravel()[np.newaxis, :]
    neighbor_freq = neighbor_votes / (cell_degree + 1e-8)
    neighbor_freq = np.nan_to_num(
        neighbor_freq,
        nan=0.0,
        posinf=1.0,
        neginf=0.0,
    )
    return np.clip(neighbor_freq, 0.0, 1.0)


def compute_zero_support_confidence(X_raw, A_gate):
    """Return median zero-entry support and the full support matrix."""
    zero_mask = X_raw == 0
    neighbor_freq = compute_neighbor_frequency(X_raw, A_gate)
    zero_neighbor_values = neighbor_freq[zero_mask]

    if zero_neighbor_values.size == 0:
        return 1.0, neighbor_freq

    confidence = float(np.quantile(zero_neighbor_values, 0.50))
    return confidence, neighbor_freq
